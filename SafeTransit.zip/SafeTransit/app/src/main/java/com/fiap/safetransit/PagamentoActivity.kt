package com.fiap.safetransit

import androidx.activity.ComponentActivity
import android.widget.TextView
import android.os.Bundle

class PagamentoActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pagamento)

        // Receber o valor do transporte da intent
        val valorTransporte = intent.getStringExtra("valorTransporte")

        // Referência ao elemento de texto para exibir o valor do transporte
        val textViewValorPagamento: TextView = findViewById(R.id.textViewValorPagamento)

        // Verificar se o valor do transporte foi recebido
        if (valorTransporte != null) {
            // Exibir o valor do transporte para o usuário
            textViewValorPagamento.text = "Valor do Transporte: R$ $valorTransporte"
        } else {
            // Caso o valor do transporte não tenha sido recebido, exibir uma mensagem de erro
            textViewValorPagamento.text = "Erro: Valor do Transporte não recebido."
        }
    }
}