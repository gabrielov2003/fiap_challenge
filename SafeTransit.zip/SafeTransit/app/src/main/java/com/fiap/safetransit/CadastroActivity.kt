package com.fiap.safetransit

import android.os.Bundle
import androidx.activity.ComponentActivity
import android.content.Intent
import android.widget.Button

class CadastroActivity: ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        val buttonSalvar: Button = findViewById(R.id.buttonSalvar)
        buttonSalvar.setOnClickListener {
            val intent = Intent(this, PesquisaRota::class.java)
            startActivity(intent)
        }

        val buttonSair: Button = findViewById(R.id.buttonSair)
        buttonSair.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
