package com.fiap.safetransit

import android.os.Bundle
import androidx.activity.ComponentActivity
import android.content.Intent
import android.widget.Button

class PesquisaRota : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pesquisa_rota)

        // Referências aos elementos do layout
        val buttonConfirmar: Button = findViewById(R.id.buttonConfirmar)

        // Configurar o clique no botão "Confirmar"
        buttonConfirmar.setOnClickListener {
            // Redirecionar para a activity Rotas.kt
            val intent = Intent(this, Rotas::class.java)
            startActivity(intent)
        }
    }
}