package com.fiap.safetransit

import androidx.activity.ComponentActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton

class Rotas : ComponentActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rotas)

        // Referências aos elementos do layout
        val buttonConfirmarRotas: Button = findViewById(R.id.buttonConfirmarRotas)
        val radioButtonMetro: RadioButton = findViewById(R.id.radioButtonMetro)
        val radioButtonTaxi: RadioButton = findViewById(R.id.radioButtonTaxi)
        val radioButtonUber: RadioButton = findViewById(R.id.radioButtonUber)

        // Configurar o clique no botão "Confirmar"
        buttonConfirmarRotas.setOnClickListener {
            // Verificar se alguma opção de transporte foi selecionada
            if (radioButtonMetro.isChecked || radioButtonTaxi.isChecked || radioButtonUber.isChecked) {
                // Obter o valor da opção de transporte selecionada
                val valorTransporte = when {
                    radioButtonMetro.isChecked -> "4.00"
                    radioButtonTaxi.isChecked -> "15.00"
                    else -> "10.00"  // Uber como padrão
                }

                // Redirecionar para a activity Pagamento.kt e enviar o valor do transporte
                val intent = Intent(this, PagamentoActivity::class.java)
                intent.putExtra("valorTransporte", valorTransporte)
                startActivity(intent)
            }
            // Caso contrário, não faz nada
        }
    }
}