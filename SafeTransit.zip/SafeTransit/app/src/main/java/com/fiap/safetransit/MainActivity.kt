package com.fiap.safetransit

import android.os.Bundle
import androidx.activity.ComponentActivity
import android.content.Intent
import android.widget.Button

class MainActivity : ComponentActivity() {

    private lateinit var buttonEntrar: Button
    private lateinit var cadastro: Button
    private lateinit var buttonEntrarGoogle: Button
    private lateinit var buttonEntrarFacebook: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonEntrar = findViewById(R.id.buttonEntrar)
        cadastro = findViewById(R.id.cadastro)
        buttonEntrarGoogle = findViewById(R.id.buttonEntrarGoogle)
        buttonEntrarFacebook = findViewById(R.id.buttonEntrarFacebook)

        buttonEntrar.setOnClickListener {
            val intent = Intent(this, PesquisaRota::class.java)
            startActivity(intent)
        }

        cadastro.setOnClickListener {
            val intent = Intent(this, CadastroActivity::class.java)
            startActivity(intent)
        }


        buttonEntrarGoogle.setOnClickListener {
            // Lógica para lidar com o clique no botão Entrar com Google
        }

        buttonEntrarFacebook.setOnClickListener {
            // Lógica para lidar com o clique no botão Entrar com Facebook
        }
    }
}